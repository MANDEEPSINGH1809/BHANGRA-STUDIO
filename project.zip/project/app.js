var express = require('express');
var app = express();
var session = require('express-session');
var conn = require('./dbConfig');

app.set('view engine','ejs');
app.use(session({
    secret: 'yoursecret',
    resave: true,
    saveUninitialized: true

}));

app.use('/public', express.static('public'));

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.get ('/', function (req,res){res.render("home");
});

app.get('/login', function(req, res){
    res.render('login.ejs');
});


app.post('/auth', function(req, res){
    let name = req.body.username;
    let password = req.body.password;
     console.log(name);
     console.log(password);
    if (name && password) {
        conn.query('SELECT * FROM booking WHERE name = ? AND password = ?', [name, password],
    function(error, results, fields) {
        if (error) throw error;
        if (results.length > 0) {
            req.session.loggedin = true;
            req.session.username = name;
            res.redirect('/addMPs');
        } else {
            res.send('Incorrect Username and/or Password!');

        }
    res.end();
    });
}else{
    res.send('Please enter Username and/or Password');
    res.end();
}
});
// Users can access this if they are logged in
app.get('/addMPs', function(req,res,next){
    if (req.session.loggedin){
        res.render('addMPs');
    }
    else{
        res.send('Please login to view this page!');
    }

});

app.post('/addMPs' , function(req,res,next) {
    var name = req.body.name;
    var number = req.body.number;
    console.log(req.body);
    var sql = `INSERT INTO listbooking (name,number) VALUES ("${name}", "${number}")`;
    conn.query(sql, function(err, result) {
       if (err) throw err;
       console.log('record inserted');
       res.render('addMPs');
    });
 });

 app.post('/register' , function(req,res,next) {
    var name = req.body.name;
    var password = req.body.password;
    console.log(req.body);
    var sql = `INSERT INTO booking (name,password) VALUES ("${name}", "${password}")`;
    conn.query(sql, function(err, result) {
       if (err) throw err;
       console.log('record inserted');
       res.render('register');
    });
 });


app.get('/listbooking', function (req, res){
    conn.query('SELECT * FROM listbooking', function(err, result){
        if (err) throw err;
    console.log(result);
     res.render('listbooking', { title: 'List of NZ MPs', listbookingData: result});
});
});

app.get('/register', function ( req, res){
    res.render("register");
});

app.get('/aboutBhangra', function ( req, res){
    res.render("aboutBhangra");
});

app.get('/morningClasses', function ( req, res){
    res.render("morningClasses");
});


app.get('/addMPs', function (req,res){
    res.render("addMPs");
});

app.get('/classes', function (req,res){
    res.render("classes");
});

    app.get('/logout',(req,res)=>{
        req.session.destroy();
        res.redirect('/');
    });

app.listen(3000);
console.log('Node app is running on port 3000');